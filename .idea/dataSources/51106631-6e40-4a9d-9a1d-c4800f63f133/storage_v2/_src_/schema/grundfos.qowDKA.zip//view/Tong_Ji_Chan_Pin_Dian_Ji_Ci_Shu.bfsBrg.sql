create view 统计产品点击次数 as
select count(`g`.`click`) AS `count(g.click)`
from (`grundfos`.`xk_goods` `g`
       join `grundfos`.`xk_category` `c` on ((`g`.`category` = `c`.`id`)))
where (`c`.`group_id` = 4);

