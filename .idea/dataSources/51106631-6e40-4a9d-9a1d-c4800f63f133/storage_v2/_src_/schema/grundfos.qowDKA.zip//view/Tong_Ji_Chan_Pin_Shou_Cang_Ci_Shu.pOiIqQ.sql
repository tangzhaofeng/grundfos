create view 统计产品收藏次数 as
select count(`g`.`total`) AS `count(g.total)`
from (`grundfos`.`xk_goods` `g`
       join `grundfos`.`xk_category` `c` on ((`g`.`category` = `c`.`id`)))
where (`c`.`group_id` = 4);

