create view 统计每月加入的人数 as
select `m`.`id` AS `id`
from (`grundfos`.`xk_member` `m`
       join `grundfos`.`xk_member_openid_unionid` `ou` on ((`m`.`unionid` = `ou`.`unionid`)))
where ((unix_timestamp(`ou`.`create_time`) < unix_timestamp('2018-04-30 23:00:00')) and (`ou`.`bu_id` = 1));

